package modelVO;

public class CampoVazioException extends Exception{

	public CampoVazioException(String mensagem) {
		super(mensagem);
	}
	
}
